# Avant de commencer

Tu reprends un travail de rédaction déjà engagé avec l’enseignant. Ce fichier transmet le contexte et l’état du travail pour pouvoir continuer dans une nouvelle conversation.

## Le module

Le module d’expérimentation IA s’adresse aux B2 et B3 en Bachelor Design Graphique à Condé Nice. Les étudiants utilisent déjà les outils d’IA, sans nécessairement connaître leur fonctionnement ni le développement web.

Ils réalisent un site de 1 à 3 pages en deux journées communes : préparer les contenus, produire les images, puis construire et corriger le site. Les B3 disposent aussi d’une séance préalable dans Figma pour préparer leur design system et leur zoning. Les B2 s’appuient sur un moodboard.

La théorie doit leur donner les repères nécessaires pour guider les outils et reprendre les résultats selon leurs propres choix graphiques et éditoriaux. Le premier bloc « Comprendre les outils » ne dure que 30 minutes : chaque notion doit rester proportionnée à ce temps.

## Les documents à lire

Avant de proposer du contenu, lis :

1. [instructions.md](instructions.md) : la manière de rédiger et de travailler avec l’enseignant.
2. [syllabus.md](syllabus.md) : les objectifs, les publics et les rendus.
3. [déroullé.md](déroullé.md) : la progression et le temps disponible.
4. Les trois références validées ci-dessous, dans leur intégralité.

## Ce que signifie « cours n°… » ici

Dans le dossier « modèles, interfaces et usages », chaque fichier numéroté correspond actuellement à **une slide**, avec assez de texte pour soutenir l’explication orale. « Faire le cours n° 4 » signifie préparer la quatrième slide, pas développer un chapitre complet en plusieurs slides.

Les références validées sont :

- [1 — Derrière le mot « IA »](modèles,%20interfaces%20et%20usages/1.md)
- [2 — Modèle ≠ interface](modèles,%20interfaces%20et%20usages/2.md)
- [3 — Les modèles de langage — LLM](modèles,%20interfaces%20et%20usages/3.md)

Observe leur longueur, leur vocabulaire et la manière dont les explications s’enchaînent. Le fichier 3 est la référence la plus récente : il a été ajusté avec l’enseignant, notamment pour présenter l’entraînement, le prompt et le contexte en liste, puis expliquer la prédiction avec l’exemple du téléphone.

## État du travail à la reprise

Les slides 1 à 6 sont validées et enregistrées. La slide 3 présente la génération de texte par le LLM. La slide [4.md](modèles,%20interfaces%20et%20usages/4.md), « Le « sampling » du LLM », est validée et enregistrée. Elle explique la sélection du token suivant avec l’exemple « Le chat s’est endormi sur le… », puis montre comment chaque choix influence la suite et pourquoi un même prompt peut produire des réponses différentes. Elle remplace la slide sur l’entraînement, rétablie par erreur.

La slide sur les modèles de diffusion est validée et déplacée dans [5.md](modèles,%20interfaces%20et%20usages/5.md). Elle commence par la création d’une image à partir d’un prompt et de bruit aléatoire, puis explique l’entraînement sur des images bruitées. Cet ordre permet de comprendre pourquoi on parle d’images existantes pendant l’entraînement alors que l’utilisateur souhaite créer une nouvelle image.

Le sampling du LLM est présenté séparément de son fonctionnement général, dans la slide 4, avant les modèles de diffusion en slide 5. La slide [6.md](modèles,%20interfaces%20et%20usages/6.md), consacrée au sampling du modèle de diffusion, fait le lien avec la variation des réponses du LLM, puis explique le rôle du bruit de départ et de la seed. L’enseignant a choisi cette version courte, sans développer le sampler ni le nombre d’étapes, car la slide 5 explique déjà le débruitage.

L’enseignant a demandé de retirer les tirets médians de la version validée. Les slides 1 à 3 restent les références de style choisies.

## Comment reprendre

Appuie-toi sur ces lectures pour proposer directement une première version adaptée à la demande. Si le sujet est déjà indiqué, rédige ; pose une question seulement si une ambiguïté change réellement le contenu à produire.

Le texte se travaille d’abord dans la conversation. Le fichier est créé ou modifié une fois la formulation validée, sauf demande explicite d’écriture directement dans le fichier. « Il va falloir faire le cours n° 4 » ouvre le travail de rédaction ; ce n’est pas à lui seul une demande d’enregistrement.

Lorsqu’un nouveau contenu est validé et enregistré, mets à jour la section « État du travail à la reprise » pour que la conversation suivante dispose d’un état fidèle. Conserve les références de style choisies ici tant que l’enseignant ne les remplace pas.
